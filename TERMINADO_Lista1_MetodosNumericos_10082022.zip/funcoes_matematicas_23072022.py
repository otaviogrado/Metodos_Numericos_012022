# MULTIPLICAÇÃP MATRICIAL
def multiplica_matriz(ma, mb):
    mr = matriz_nula()                  # gera matriz auxiliar
    linhas_mr = len(ma)
    colunas_mr = len(mb[0])
    for i in range(linhas_mr):          # loop para realizar o produto
        for j in range(colunas_mr):
            for k in range(len(mb)):
                mr[i][j] = mr[i][j] + ma[i][k] * mb[k][j]
    return mr


# GERA MATRIZ NULA 3 x 3
def matriz_nula():
    m = 3 * [0]
    for i in range(3):
        m[i] = 3 * [0]
    return m


# REGRA DE SARRUS
def regra_sarrus(m_sarrus):
    positivo = 0
    negativo = 0
    soma = 0
    for j in range(len(m_sarrus)):
        positivo = positivo + (m_sarrus[0][j] * m_sarrus[(1)][(j+1)%(len(m_sarrus))] * m_sarrus[(2)][(j+2)%(len(m_sarrus))])
        negativo = negativo + (m_sarrus[2][j] * m_sarrus[(1)][(j+1)%(len(m_sarrus))] * m_sarrus[(0)][(j+2)%(len(m_sarrus))])
        soma = positivo - negativo
    return soma


# TEOREMA DE LAPLACE (para matrizes 4x4)
def det_laplace(mc):

    # variáveis locais
    operacao = []
    md = [[0,0,0],[0,0,0],[0,0,0]]
    l_mat = 4 * [0]
    det_mat = 4 * [0]
    res_mat = 4 * [0]
    soma = 0

    for k in range(4):
        operacao.append(mc[0][k])                       # adiciona o numero Aij da matriz 4x4 em uma lista
        operacao[k] = operacao[k] * ((-1) ** (k))       # opera o numero Aij por -1**(i+j)
        for i in range(3):
            for j in range(3):
                md[i][j] = mc[(i+1)][(j+1+k)%(4)]       # gerar uma matriz auxiliar para adicionar numa lista com os cofatores de Aij
        l_mat[k] = md                                   # lista de cofatores
        md = [[0,0,0],[0,0,0],[0,0,0]]
        det_mat[k] = regra_sarrus(l_mat[k])             # adiciona determinantes em uma lista calculados via regra de sarrus
        res_mat[k] = operacao[k] * det_mat[k]           # adiciona o determinante da operacao:  Aij * (-1)**(i+j) * (cofatores) em uma matriz
        soma = soma + res_mat[k]                        # calcula o determinate final da matriz 4x4

    return soma                                         # retorna o valor do determinate
    
    
# MATRIZ TRANSPOSTA
def transposicao_matrizes(m_transp):
    ml = matriz_nula()
    for i in range(len(m_transp)):
        for j in range(len(m_transp[0])):
            ml[j][i] = m_transp[i][j]
    return ml

