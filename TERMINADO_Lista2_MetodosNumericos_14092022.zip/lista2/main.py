# LISTA 2 - MÉTODOS NUMÉRICOS

'''
#    ************************************* EXERCÍCIO 1 *************************************
# BIBLIOTECAS
import numpy as np
import matplotlib.pyplot as plt


# FUNCOES AUXILIARES
def plotagem(x,y):
    plt.figure(figsize=(8, 8))
    plt.plot(x, y)
    plt.axis('scaled')
    plt.suptitle('EXERCICIO 1')
    plt.xlabel('cos(x)')
    plt.ylabel('sen(x)')
    plt.show()


# VARIÁVEIS
num = np.linspace(-np.pi, np.pi, 100)       # valores de -pi até pi
x = np.cos(num)                             # valores de x
y = np.sin(num)                             # valores de y
plotagem(x,y)                               # plotagem gráfica
'''


'''
#    ************************************* EXERCÍCIO 2 ************************************* 

# bibliotecas
import matplotlib.pyplot as plt
import numpy as np

# variáveis globais
x = np.arange(-np.pi, np.pi, 0.2)                        # valores de -pi a pi com passo 0.2
l_pontos = []                                            # lista vaiza para armazenar valores

# formatos = ['-', '--', ':','-.', '.', 'o']             # não funciona o comando passado pelo professor
formatos = ['-', '--', ':', '-.', '--', ':']
cores = ['b', 'g', 'r', 'c', 'm', 'y']

for i in range(6):                                       # loop para realizar iterações
    plt.grid()                                           # grid inicial para todos os gráficos

    l_pontos.append(np.sin(x - 0.2 * i))                 # comandos principais
    plt.subplot(3, 2, i + 1)
    plt.plot(x, l_pontos[i], linestyle=formatos[i], color=cores[i])

    plt.title(f"Gráfico sen(x-{round(0.2 * i, 2)})")     # printa o titulo com arredondamento para duas casas decimais do valor de 0.2*i
    plt.xlabel('Eixo x')
    plt.ylabel('Eixo Y')

plt.grid()  # grid no ultimo gráfico
plt.suptitle('EXERCICIO 2')
plt.show()
'''


'''
#    ************************************* EXERCÍCIO 3 ************************************* 

# BIBLIOTECAS
import matplotlib.pyplot as plt
import numpy as np

# FUNÇÕES AUXILIARES
def f(x):
    return -(2 * (x ** 4)) + (3 * (x ** 3)) + (7 * (x ** 2)) - (10 * x) + 18

def g(x):
    return (x ** 4) + (2 * (x ** 3)) - (13 * (x ** 2)) - (14 * x) + 24

def plotagem(eixoX, eixoY1, eixoY2):
    fig, ax = plt.subplots()
    ax.spines['top'].set_color('none')              # eixo lateral invisível
    ax.spines['right'].set_color('none')
    ax.xaxis.set_ticks_position('bottom')           # orienta no na origem o gráfico
    ax.spines['bottom'].set_position(('axes', 0))
    ax.yaxis.set_ticks_position('left')
    ax.spines['left'].set_position(('axes', 0))
    plt.plot(eixoX, eixoY1, label='Gráfico f(x)')   # plotagem gráfica das funções
    plt.plot(eixoX, eixoY2, label='Gráfico g(x)')
    plt.title('EXERCICIO 3')                        # layout do gráfico
    plt.xlabel('Eixo X')
    plt.ylabel('Eixo Y')
    plt.legend()
    plt.grid()
    plt.show()


# VARIÁVEIS
eixoX = np.linspace(-4.5, 4.5, 300)                 # gera valores de -4,5 a 4,5
f1 = np.vectorize(f)
f2 = np.vectorize(g)
eixoY1 = f1(eixoX)
eixoY2 = f2(eixoX)
plotagem(eixoX, eixoY1, eixoY2)                     # plotagem gráfica
'''


'''
#    ************************************* EXERCÍCIO 4 ************************************* 

# BIBLIOTECAS
import numpy as np
import random


# FUNÇÕES AUXILIARES
def myfunc(a, b):  # funcao que retorna valor maior
    if a >= b:
        return a
    else:
        return b


# EXERCICIO A:
a = 10 * [0]                                        # gera lista com 10 elementos
b = 10 * [0]
for i in range(10):                                 # laço for para gerar lista com 10 elementos inteiros
    a[i] = random.randrange(10, 99)
    b[i] = random.randrange(10, 99)
array_a = np.array(a)                               # transforma lista na classe array
array_b = np.array(b)
vfunc = np.vectorize(myfunc)                        # vetorização do array para operar sobre ele
valor = vfunc(array_a, array_b)                     # maior entre vetores

#print(array_a)
#print(array_b)
#print('ARRAY RESULTADO\t', valor)                  # valor final


# EXERCÍCIO B:
aa = 10 * [0]                                       # gera lista com 10 elementos
bb = 10 * [0]
for i in range(10):                                 # laço for para gerar lista com 10 elementos inteiros 
    aa[i] = random.random()
    bb[i] = random.random()
array_aa = np.array(aa)                             # transforma lista na classe array
array_bb = np.array(bb)
vfunc_2 = np.vectorize(myfunc)                      # vetorização do array para operar sobre ele
valor_2 = vfunc_2(array_aa, array_bb)               # maior entre vetores

print('ARRAY A\n', array_aa)
print('\nARRAY B\n', array_bb)
print('\nARRAY RESULTADO\n',valor_2)                # valor final
'''


'''
#    ************************************* EXERCÍCIO 5 ************************************* 

# BIBLIOTECAS
import numpy as np
import matplotlib.pyplot as plt

# ENTRADA DAS VARIÁVEIS
passo = float(input('Entre com o valor do passo:\t'))


# 
# ------------------------------------------  exercicio A ------------------------------------
inicio = 1
fim = 5
solucao = 15

x = np.arange(inicio, fim, passo)
z = [-passo/2, 0, passo/2]

xx = len(x) * [0]                  # gera lista com valores de x
for i in range(len(x)):
    xx[i] = x[i] + (passo/2)   

for k in range(len(z)):            # lista com valores de y
    y = len(x) * [0]
    for i in range(len(x)):
        y[i] = 2 * (xx[i] + z[k]) 

    area = len(x) * [0]            # calculo da area
    for i in range(len(x)-1):
        area[i+1] = (xx[i+1] - xx[i]) * (y[i]) + area[i]

    erro = len(x)*[0]              # calculo do erro
    erro[k] = abs(((area[len(x)-1]-solucao)/solucao)*100)

    print('xx\t', xx)
    print('y\t', y)        
    print('area\t', area)
    print('erro\t', erro[k], '%')
    print()

fig, axs = plt.subplots(3,1,sharex= True, figsize = (8,20))       # plotagem das figuras
plt.suptitle('Exercício 5')                      # título
plt.subplots_adjust(wspace = 0.25, hspace=0.5)                    # ajuste de espaço entre gráficos


axs[0].plot(x, y, 'r', marker = 'o', label = 'f(x)')
axs[0].bar(x+z[0],y, width = passo)
axs[0].set_xlabel('eixo x')                                           # configuração dos eixos
axs[0].set_ylabel('eixo y')
axs[0].set_title(f'Erro relativo:  {erro[0]}%')                          # subtítulo
#axs[0].set_xlim((x[0]),(x[len(x)-1]*1.25))                            # limite do eixo x
axs[0].legend()
axs[0].grid()

axs[1].plot(x, y, 'b', marker = '*', label = 'f(x)')     # plotagem gráfico 2: função de Euler
axs[1].bar(x+z[1],y, width = passo)
axs[1].set_xlabel('eixo x')                                           # configuração dos eixos
axs[1].set_ylabel('eixo y')
axs[1].set_title(f'Erro relativo:  {erro[1]}%')                                  # subtítulo
axs[1].legend()
axs[1].grid()

axs[2].plot(x, y, 'k', marker = '+', label = 'f(x)')     # plotagem gráfico 3: comportamento na origem
axs[2].bar(x+z[2],y, width = passo)
axs[2].set_xlabel('eixo x')                                          # configuração dos eixos
axs[2].set_ylabel('eixo y')
axs[2].set_title(f'Erro relativo:  {erro[2]}%')                           # subtítulo
#axs[2].set_ylim(-5, 5)                                                # limite do eixo y
axs[2].legend()
axs[2].grid()

plt.show()
'''

'''
# ------------------------------------------  exercicio B ------------------------------------
# b) Para a função f(x) = 1/8(x^2 -2x + 8), integrada no intervalo [-2, 4], cuja solução analítica é 15/6.
def plotagem(x, y, z, passo):
    fig, axs = plt.subplots(3, 1, sharex=True, figsize=(8, 20))  # plotagem das figuras
    plt.suptitle('Exercício 5 - Questão B')  # título
    plt.subplots_adjust(wspace=0.25, hspace=0.5)  # ajuste de espaço entre gráficos

    cores = ['r', 'b', 'k']
    marcadores = ['o', '*', '+']

    for k in range(len(z)):
        axs[k].plot(x, y[k], cores[k], marker=marcadores[k], label='f(x)')
        axs[k].bar(x + z[k], y[k], width=passo)
        axs[k].set_xlabel('eixo x')  # configuração dos eixos
        axs[k].set_ylabel('eixo y')
        axs[k].set_title(f'Erro relativo ao passo {z[k]}:  {erro[0]}%')  # subtítulo
        axs[k].legend()
        axs[k].grid()

    plt.show()


inicio = -2
fim = 4
solucao = 15 / 6

x = np.arange(inicio, fim, passo)
z = [-passo / 2, 0, passo / 2]

xx = len(x) * [0]
yy = len(xx) * [0]
y = [yy, yy, yy]
a = len(xx) * [0]
area = [a, a, a]
erro = len(z) * [0]

for k in range(len(z)):
    for i in range(len(x)):
        xx[i] = x[i] + (passo / 2)                                              # calculo de x
        y[k][i] = 1 / (8 * (((xx[i] + z[k]) ** 2) - 2 * ((xx[i] + z[k]) + 8)))  # valores de y
    for i in range(len(xx) - 1):
        area[k][i + 1] = area[k][i] + ((xx[i + 1] - xx[i]) * y[k][i + 1])       # valores da area
    erro[k] = abs((area[k][len(xx) - 1] - solucao) / solucao)                   # calculo do erro em relacao ao passo
    print(f'Area com passo de {z[k]}\t\t{abs(area[k][len(xx) - 1])}')
    print(f'Erro com passo de {z[k]}\t\t{erro[k]}')
    print()

plotagem(x, y, z, passo)  
'''
