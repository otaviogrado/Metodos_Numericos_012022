# MULTIPLICAÇÃP MATRICIAL
def multiplica_matriz(ma, mb):
    mr = matriz_nula()                  # gera matriz auxiliar
    linhas_mr = len(ma)
    colunas_mr = len(mb[0])
    for i in range(linhas_mr):          # loop para realizar o produto
        for j in range(colunas_mr):
            for k in range(len(mb)):
                mr[i][j] = mr[i][j] + ma[i][k] * mb[k][j]
    return mr


# GERA MATRIZ NULA 3 x 3
def matriz_nula():
    m = 3 * [0]
    for i in range(3):
        m[i] = 3 * [0]
    return m


# REGRA DE SARRUS
def regra_sarrus(m_sarrus):
    positivo = 0
    negativo = 0
    soma = 0
    for j in range(len(m_sarrus)):
        positivo = positivo + (m_sarrus[0][j] * m_sarrus[(1)][(j+1)%(len(m_sarrus))] * m_sarrus[(2)][(j+2)%(len(m_sarrus))])
        negativo = negativo + (m_sarrus[2][j] * m_sarrus[(1)][(j+1)%(len(m_sarrus))] * m_sarrus[(0)][(j+2)%(len(m_sarrus))])
        soma = positivo - negativo
    return soma


# TEOREMA DE LAPLACE (para matrizes 4x4)
def laplace_cofator_ordem4(m_laplace):
    m_auxiliar = [[0,0,0], [0,0,0], [0,0,0]]

    for i in range(len(m_laplace) - 1):                    # construção da matriz Aij
        for j in range(len(m_laplace) - 1):
            m_auxiliar[i][j] = m_laplace[(i + 1) % (len(m_laplace))][(j + 1) % (len(m_laplace))]
 
    resultado = regra_sarrus(m_auxiliar)
    return resultado
    
    
# MATRIZ TRANSPOSTA
def transposicao_matrizes(m_transp):
    ml = matriz_nula()
    for i in range(len(m_transp)):
        for j in range(len(m_transp[0])):
            ml[j][i] = m_transp[i][j]
    return ml

