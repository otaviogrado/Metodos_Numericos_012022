# BIBLIOTECAS
import numpy as np
import matplotlib.pyplot as plt


# FUNÇÕES AUXILIARES
def funcao():                                                                     # configuração da função
    print('dada a função: f(x) = a.x³ + b.x² + c.x + d, entre com os valores:\n')
    const_a = float(input("Entre com o valor de 'a':\t"))
    const_b = float(input("Entre com o valor de 'b':\t"))
    const_c = float(input("Entre com o valor de 'c':\t"))
    const_d = float(input("Entre com o valor de 'd':\t"))
    print()
    return const_a, const_b, const_c, const_d

def parametros_iniciais(a, b, c, d):
    x0 = float(input('Entre com os valores da abscissa inicial "x0":\t\t'))       # abscissa inicial
    xf = float(input('Entre com os valores da abscissa final "xf":\t\t'))         # abscissa final
    y0 = calcula_funcao(x0, a, b, c, d)                                         # calcula ordenada inicial
    print(f'O valor de "y0" segundo o cálculo Hardcoded de "f(x0)" é:\t{y0}')
    h = float(input('Entre com o valor do passo "h":\t\t\t\t'))                   # passo
    print()
    return x0, y0, xf, h

def calcula_funcao(x,a,b,c,d):                                        # função genérica para calculo dos valores da funcão até 3° Ordem
    return (a*(x**3))+(b*(x**2)+(c*x)+d)

def derivada(x, a, b, c):                                             # calculo da derivada de ordem 3
    return (3*a*(x**2))+(2*b*x)+c

def calculo_derivada(x, a, b, c):                                     # impressão da derivada
    y = len(x) * [0]
    for i in range(len(x)):
        y[i] = derivada(x[i], a, b, c)
    return y

def plotagem(x,y,fx):
    plt.plot(x,y, 'o', label = 'Euler y(x)')                              # plota pontos da funcao do metodo de Euler
    plt.plot(x,fx,color = 'r', label = 'Função f(x)')                     # plota pontos da funcao f(x) configurada
    plt.grid(True, which='both')                                          # plota as linhas do gráfico
    plt.axhline(y=0, color='k')                                           # configura as linhas x = 0 e y = 0
    plt.axvline(x=0, color='k')
    plt.ylim((-fx[len(x)-1])*1.25, (fx[len(x)-1])*1.25)                 # estabelece o limite de plotagem do gráfico
    plt.xlim((x[0]-1)*1.1,(x[len(x)-1]+1)*1.1)
    plt.title("GRÁFICO DA FUNÇÃO f(x) e y(x):", color = 'b')              # Titulo do gráfico
    plt.legend()
    plt.show()

def erro_relativo(xf, y, fx, x):
    print(f'O valor de "yf" para {xf} é:\t\t\t{y[len(x)-1]}\t\t~ via Método de Euler')
    print(f'O valor de "yf" para {xf} é:\t\t\t{fx[len(x)-1]}\t\t~ via Cálculo Hardcoded')
    erro = abs((y[len(x)-1]-fx[len(x)-1])/fx[len(x)-1])*100
    print(f'O valor do erro relativo foi de:\t\t{erro}% ou {round(erro, 3)}%')


# REFERENCIAS PARA INSTRUÇÃO:
#  https://cn.ect.ufrn.br/index.php?r=conteudo%2Fedo-euler
#  https://www.ufrgs.br/reamat/CalculoNumerico/livro-py/main.html
#  http://www.mat.ufrgs.br/~guidi/grad/MAT01169/calculo_numerico.pdf