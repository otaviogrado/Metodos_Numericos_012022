def metodo_euler(x, y0, h, df):
    n = len(x)                                                        # n pontos gerados
    y = n * [0]                                                       # matriz para armazenar valores calculados para função
    y[0] = y0                                                         # recebe valor de y0 para matriz dos valores da funcao Y
    for i in range(n-1):                                              # MÉTODO DE EULER  - aplicação
        y[i+1] = y[i] + (h * df[i])
    return y


# REFERENCIAS PARA INSTRUÇÃO:
#  https://cn.ect.ufrn.br/index.php?r=conteudo%2Fedo-euler
#  https://www.ufrgs.br/reamat/CalculoNumerico/livro-py/main.html
#  http://www.mat.ufrgs.br/~guidi/grad/MAT01169/calculo_numerico.pdf