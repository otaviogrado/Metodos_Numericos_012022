# BIBLIOTECAS
import numpy as np
from Metodo_Euler import *
from functions import *


# FUNÇÃO MAIN()
a, b, c, d = funcao()                                               # entra com a função
x0, y0, xf, h = parametros_iniciais(a, b, c, d)                       # entra com os dados x0, xf, y0 e passo
x = np.arange(x0, xf+h, h)                                            # gera todos os pontos a serem usados
df = calculo_derivada(x,a,b,c)                                        # calculo das derivadas com pontos de 'x' dados
fx = calcula_funcao(x,a,b,c,d)                                        # calcula valores da funcao f(x) com os pontos de 'x' dados
y = metodo_euler(x, y0, h, df)                                        # calculo dos pontos via Metodo de Euler
erro_relativo(xf, y, fx, x)                                              # calculo do erro relativo
plotagem(x,y,fx)                                                      # funcao para plotar gráfico


# REFERENCIAS PARA INSTRUÇÃO:
#  https://cn.ect.ufrn.br/index.php?r=conteudo%2Fedo-euler
#  https://www.ufrgs.br/reamat/CalculoNumerico/livro-py/main.html
#  http://www.mat.ufrgs.br/~guidi/grad/MAT01169/calculo_numerico.pdf


# OBSERVAÇÕES SOBRE O ALGORITMO
# Pode-se otimizar o codigo deixando tudo em uma funcao main(), realocar ela na bib function e chamar nesse codigo principal
# funciona muito bem para funcões constantes e do primeiro grau
# trava para valores de x0 > xf
# grafico não plota direito se valores de 'a' forem muito grandes ou valores de abs(xf) >> abs(x0)
# para alguns valores de f(x) iniciais serão cortados do gráfico, se colocar (-f([0]*1,25) o gráfico fica desproporcional e não plota direito