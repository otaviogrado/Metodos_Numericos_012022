# PASSO 9: montar MENU com todas as opções

# BIBLIOTECAS
from funcoes_matematicas_23072022 import *
from funcoes_que_imprimem_23072022 import *
import numpy as np


print("************************* CALCULADORA DE MATRIZES *************************\n")

# VARIAVEIS GLOBAIS
ma = cria_chama_matriz()  # matriz A
mb = cria_chama_matriz()  # matriz B
bottom = 10

# FUNÇÃO MAIN()
while bottom != 0:
    print("------------------- MENU OPÇÕES -------------------")
    print("0 - SAIR\n"
          "1 - VERIFICA MATRIZ\n"
          "2 - multiplicar matrizes\n"
          "3 - multiplicar matriz por escalar\n"
          "4 - Maior, menor e soma dos elementos da matriz\n"
          "5 - determinante matriz 3x3 (Regra de Sarrus)\n"
          "6 - determinante matriz 4x4 (Teorema de Laplace)\n"
          "7 - transposta de matriz\n")

    bottom = int(input("Selecione uma das opções:\t"))
    print()

    if bottom == 1:  # VERIFICA matriz
        verifica_matriz(ma, mb)                                         # via python normal

        ic, jc  = (np.array(ma)).shape                                  # via numpy
        id, jd = (np.array(mb)).shape
        if jc == id:
            print("o produto matricial é possivel!!\t\t~ (via NUMPY)\n")
        else:
            print("Impossivel resolver no produto!!\t\t~ (via NUMPY)\n")


    elif bottom == 2:  # MULTIPLICA MATRIZ POR MATRIZ
        mr = multiplica_matriz(ma, mb)                                  # via python normal
        print('A matriz resultante R é:\n')
        imprime_matriz(mr)
        print()

        MC = np.array(ma)                                               # via numpy
        MD = np.array(mb)
        MR = MC @ MD
        print(f"a MULTIPLICAÇÃO MATRICIAL será:\t( ~ via NUMPY)\n{MR}")
        print()


    elif bottom == 3:  # MATRIZ POR ESCALAR
        print(f'O produto por um escalar da matriz "MA" é:')            # via python normal
        m_escalar1 = multiplica_escalar(ma)
        imprime_matriz(m_escalar1)
        print(f'O produto por um escalar da matriz "MB" é:')
        m_escalar2 = multiplica_escalar(mb)
        imprime_matriz(mb)

        print("\tMesma operação via NUMPY\n")
        MC = np.array(ma)                                               # via numpy
        MR1 = multiplica_escalar (MC)
        print(f"a multiplicação matricial será:\t( ~ via NUMPY)\n{MR1}")
        print()
        MD = np.array(mb)
        MR2 = multiplica_escalar (MD)
        print(f"a multiplicação matricial será:\t( ~ via NUMPY)\n{MR2}")
        print()


    elif bottom == 4:  # MAIOR, MENOR, SOMA
        print(f"Para a matriz 'MA':")                                   # via python normal
        operacao_elementos(ma)
        print(f"\nPara a matriz 'MB':")
        operacao_elementos(mb)
        print()

        MC = np.array(ma)                                               # via numpy
        MD = np.array(mb)
        print("\t\t ~ via NUMPY\n")
        print(f"a SOMA dos elementos da matriz MC é:\t{MC.sum()}")
        print(f"o MENOR dos elementos da matriz MC é:\t{MC.min()}")
        print(f"o MAIOR dos elementos da matriz MC é:\t{MC.max()}")
        print()
        print(f"a SOMA dos elementos da matriz MD é:\t{ MD.sum()}")
        print(f"o MENOR dos elementos da matriz MD é:\t{MD.min()}")
        print(f"o MAIOR dos elementos da matriz MD é:\t{MD.max()}")
        print()


    elif bottom == 5:  # DETERMINANTE 3 x 3
        m_determinante1 = regra_sarrus(ma)                              # via python normal
        print(f'O determinante da matriz: "MA" é:\t', m_determinante1)
        print()
        m_determinante2 = regra_sarrus(mb)
        print(f'O determinante da matriz: "MB" é:\t', m_determinante2)
        print()

        MC = np.array(ma)                                               # via numpy
        MC_det = np.linalg.det(MC)
        print("O valor do determinante da matriz 'MA' será:\t{%.2f}\t( ~ via NUMPY)" %MC_det)
        MD = np.array(mb)
        MD_det = np.linalg.det(MD)
        print("O valor do determinante da matriz 'MA' será:\t{%.2f}\t( ~ via NUMPY)" %MD_det)


    elif bottom == 6:  # DETERMINANTE 4 x 4 ~ valido somente para matrizes 4x4
        m_determinante1 = det_laplace(ma)
        print(f"O determinante da matriz: 'MA' é:\t", m_determinante1)
        m_determinante2 = det_laplace(mb)
        print(f"O determinante da matriz: 'MB' é:\t", m_determinante2)

        print("\n\tMesma operação realizada via NUMPY\n")
        MC = np.array(ma)
        MC_det = np.linalg.det(MC)
        print("O valor do determinante da matriz 'MA' será:\t{%.2f}" %MC_det)
        MD = np.array(mb)
        MD_det = np.linalg.det(MD)
        print("O valor do determinante da matriz 'MB' será:\t{%.2f}" %MD_det)


    elif bottom == 7:  # TRANSPOSIÇÃO DE MATRIZES
        mc = transposicao_matrizes(ma)                          # via python normal
        md = transposicao_matrizes(mb)
        imprime_matriz(mc)
        imprime_matriz(md)
        print()

        print("\n\tMesma operação realizada via NUMPY\n")
        MC = np.array(ma)                         # via numpy ---------- ARRUMAR
        MC_transp = np.transpose(MC)
        print("A matriz transposta será:\n",MC_transp)
        MD = np.array(mb)                         
        MD_transp = np.transpose(MD)
        print("A matriz transposta será:\n",MD_transp)
