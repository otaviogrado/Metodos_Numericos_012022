# CRIA MATRIZ - função chamada para gerar qualquer matriz
def cria_matriz():
    print("\t---------- FUNÇÃO CRIA MATRIZ ACIONADA ----------")
    qtde_linhas = int(input("Entre com o numero de LINHAS da matriz:\t\t"))
    qtde_colunas = int(input("Entre com o numero de COLUNAS da matriz:\t"))

    m_cria = qtde_linhas * [0]                                                      # cria dimensão da matriz de acordo com numero de linhas e colunas
    for i in range(qtde_linhas):
        m_cria[i] = qtde_colunas * [0]

    for i in range(qtde_linhas):
        for j in range(qtde_colunas):
            m_cria[i][j] = int(input(f"linha {i + 1} - coluna {j + 1}:\t"))
    return m_cria


# IMPRIME MATRIZ
def imprime_matriz(m_imprime):  # fun��o para impress�o na tela da matriz resultante
    print("\n\t---------- FUNÇÃO IMPRIME MATRIZ ACIONADA ----------\n")
    for i in range(len(m_imprime)):
        for j in range(len(m_imprime[0])):
            print(m_imprime[i][j], end='   ')
        print()
    print()


# CRIA MATRIZ - função chamada para criar uma matriz específica, imprime e retorná-la a uma variável
def cria_chama_matriz():
    m = cria_matriz()
    imprime_matriz(m)
    return m


# VERIFICA PRODUTO MATRICIAL
def verifica_matriz(m1, m2):
    print("\t***** FUNÇÃO VERIFICA MATRIZ ACIONADA *****\n")
    if (len(m1) == len(m2[0])):
        print("O produto É POSSÍVEL!\n")
    else:
        print("O produto NÃO É POSSÍVEL\n")


# MULTIPLICA POR ESCALAR
def multiplica_escalar(m1):
    escalar = float(input("Entre com o valor do escalar:\t"))
    for i in range(len(m1)):
        for j in range(len(m1[0])):
            m1[i][j] = escalar * m1[i][j]
    return m1

